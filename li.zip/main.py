import os
import sqlite3
import sys
from datetime import datetime


DB_FILE = "app_data.db"


def get_connection(db_path: str = DB_FILE) -> sqlite3.Connection:
	"""Возвращает подключение к SQLite. Создаёт файл БД при первом запуске."""
	return sqlite3.connect(db_path)


def initialize_database() -> None:
	"""Создаёт таблицы, если их ещё нет."""
	with get_connection() as conn:
		conn.execute(
			"""
			CREATE TABLE IF NOT EXISTS notes (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				title TEXT NOT NULL,
				content TEXT NOT NULL,
				created_at TEXT NOT NULL
			);
			"""
		)
		conn.commit()


def add_note(title: str, content: str) -> int:
	"""Добавляет новую заметку и возвращает её id."""
	created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
	with get_connection() as conn:
		cursor = conn.execute(
			"INSERT INTO notes (title, content, created_at) VALUES (?, ?, ?)",
			(title.strip(), content.strip(), created_at),
		)
		conn.commit()
		return cursor.lastrowid


def list_notes() -> list[tuple]:
	"""Возвращает список заметок (id, title, created_at)."""
	with get_connection() as conn:
		cursor = conn.execute(
			"SELECT id, title, created_at FROM notes ORDER BY id DESC"
		)
		return list(cursor.fetchall())


def view_note(note_id: int) -> tuple | None:
	"""Возвращает полную заметку по id или None."""
	with get_connection() as conn:
		cursor = conn.execute(
			"SELECT id, title, content, created_at FROM notes WHERE id = ?",
			(note_id,),
		)
		return cursor.fetchone()


def prompt_nonempty(prompt: str) -> str:
	while True:
		value = input(prompt).strip()
		if value:
			return value
		print("Поле не может быть пустым. Повторите ввод.")


def main() -> None:
	print("Простой проект на Python + SQLite")
	print("База данных хранится в файле:", os.path.abspath(DB_FILE))
	# Небольшой парсер аргументов для неинтерактивного режима
	args = sys.argv[1:]
	if "--init-only" in args:
		initialize_database()
		print("База данных инициализирована.")
		return
	if "--demo" in args:
		initialize_database()
		title = "Демо заметка"
		content = "Это пример сохранения данных в SQLite."
		# Позволяем передать заголовок/текст как параметры после --demo
		try:
			idx = args.index("--demo")
			if len(args) > idx + 1:
				title = args[idx + 1]
			if len(args) > idx + 2:
				content = args[idx + 2]
		except ValueError:
			pass
		new_id = add_note(title, content)
		print(f"Демо-заметка сохранена с id={new_id}.")
		notes = list_notes()
		print(f"Всего заметок в базе: {len(notes)}")
		return

	initialize_database()

	while True:
		print("\nМеню:")
		print("  1) Добавить заметку")
		print("  2) Показать список заметок")
		print("  3) Просмотреть заметку по ID")
		print("  0) Выход")

		choice = input("Ваш выбор: ").strip()

		if choice == "1":
			title = prompt_nonempty("Заголовок: ")
			content = prompt_nonempty("Текст: ")
			new_id = add_note(title, content)
			print(f"Заметка сохранена с id={new_id}.")

		elif choice == "2":
			notes = list_notes()
			if not notes:
				print("Заметок пока нет.")
			else:
				print("\nID | Заголовок | Дата")
				print("-" * 40)
				for note_id, title, created_at in notes:
					print(f"{note_id} | {title} | {created_at}")

		elif choice == "3":
			id_str = prompt_nonempty("Введите ID заметки: ")
			if not id_str.isdigit():
				print("ID должен быть числом.")
				continue
			note = view_note(int(id_str))
			if note is None:
				print("Заметка не найдена.")
			else:
				note_id, title, content, created_at = note
				print("\nЗаметка:")
				print(f"ID: {note_id}")
				print(f"Заголовок: {title}")
				print(f"Дата: {created_at}")
				print("Текст:")
				print(content)

		elif choice == "0":
			print("Выход. До свидания!")
			break

		else:
			print("Неверный пункт меню. Попробуйте снова.")


if __name__ == "__main__":
	main()


